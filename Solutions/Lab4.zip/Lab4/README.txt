On login, a new Library object is created. At the end of the constructor, its begin function runs.

The Library begin function renders the table according to the Shelves' Books.

The Student being able to select two was unclear so I just made it one.