library angular2.instrumentation;

export "src/core/profile/profile.dart"
    show
        wtfCreateScope,
        wtfLeave,
        wtfStartTimeRange,
        wtfEndTimeRange,
        WtfScopeFn;
