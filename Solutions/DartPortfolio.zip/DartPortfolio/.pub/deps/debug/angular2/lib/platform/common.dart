/// Platform agnostic services.
/// Can be used both in the browser and on the server.
library angular2.platform.common;

export "package:angular2/src/platform/location.dart";
