// TODO: vsavkin rename it into TemplateLoader

/**
 * An interface for retrieving documents by URL that the compiler uses
 * to load templates.
 */

import "dart:async";

class XHR {
  Future<String> get(String url) {
    return null;
  }
}
