To launch, open index.html in Chrome.
Study Share runs locally and only has temporary memory. 